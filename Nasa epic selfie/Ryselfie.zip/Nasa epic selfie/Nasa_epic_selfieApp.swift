//
//  Nasa_epic_selfieApp.swift
//  Nasa epic selfie
//
//  Created by Ry Natterson on 1/10/23.
//

import SwiftUI

@main
struct Nasa_epic_selfieApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
