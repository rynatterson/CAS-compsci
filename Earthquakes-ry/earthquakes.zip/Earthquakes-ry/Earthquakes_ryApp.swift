//
//  Earthquakes_ryApp.swift
//  Earthquakes-ry
//
//  Created by Ry Natterson on 1/11/23.
//

import SwiftUI

@main
struct Earthquakes_ryApp: App {
    var body: some Scene {
        WindowGroup {
            EarthquakeList()
        }
    }
}
